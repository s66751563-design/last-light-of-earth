# Cinematic Shot List and Generation Prompts

## Visual bible
- Photorealistic, scientifically grounded space documentary.
- 16:9, 4K target, 24 fps; generate at the best reliable native resolution, then upscale carefully.
- Deep natural blacks, controlled highlights, realistic exposure, fine detail.
- Slow, deliberate camera movement; one camera move per shot.
- No text, captions, logos, watermarks, UI, dialogue, music, or sound effects in generated clips.
- Space is silent. The Sun is a luminous plasma sphere, not a campfire.
- Reuse reference images, seed, and color treatment where supported.

## Scene prompts
Each prompt is designed for a short 5–8 second clip. Adapt duration to the hosted model.

### 01 — Earth at night
Photorealistic orbital view of planet Earth at night, delicate city lights tracing coastlines, deep blue atmosphere, cloud systems drifting slowly, immense black space, cinematic documentary cinematography, very slow orbital camera drift, physically plausible scale and lighting, exquisite detail, 16:9, no text.

### 02 — Sunrise over Earth
From low Earth orbit, the Sun slowly rises over the curved blue limb of Earth, thin atmospheric scattering, clouds catching first golden light, restrained lens bloom, serene and scientifically plausible, slow stabilized camera movement, 16:9, no text.

### 03 — The living Sun
Extreme close-up of the solar photosphere, realistic granulation cells and subtle plasma motion, magnetic activity visible at the limb, scientifically inspired solar observatory imagery, controlled exposure preserving surface detail, slow observational camera movement, 16:9, no text.

### 04 — Inside a star
Elegant scientific visualization of the Sun's interior, layered spherical cutaway revealing a bright central core and surrounding radiative and convective regions, hydrogen fusion represented as subtle luminous activity, accurate educational documentary style, slow rotation, clean dark background, 16:9, no labels.

### 05 — A brighter future
Earth from space across deep time, the Sun subtly brighter, atmosphere and cloud patterns shifting in a restrained conceptual time-lapse, realistic planetary scale, sober scientific visualization, gradual change rather than sudden disaster, 16:9, no text.

### 06 — A changing ocean world
Wide cinematic view of a future Earth from orbit, broad cloud systems, muted oceans and sunlit atmosphere under a brighter Sun, scientifically restrained speculative environmental visualization, slow camera pullback, 16:9, no text.

### 07 — The red giant Sun
The Sun in its red giant phase, immense softly glowing orange-red stellar sphere with delicate turbulent surface texture, inner solar system suggested at realistic scale, deep black space, awe-inspiring astronomical visualization, slow distant camera movement, 16:9, no text.

### 08 — Earth in the red giant era
A small rocky Earth seen from far away near a vast red giant Sun, dramatic scale but physically grounded lighting, no flames or explosion, solemn scientific concept visualization rendered as photorealistic documentary footage, slow pullback, 16:9, no text.

### 09 — A future orbital habitat
Large rotating space habitat with agricultural ring, windows, structural trusses and soft interior lights, blue planet distant in background, realistic engineering design, cinematic documentary realism, slow tracking shot, 16:9, no text or logos.

### 10 — The interstellar vessel
Plausible long-duration interstellar spacecraft, modular habitat sections, radiators and propulsion assembly, small against a vast star field, detailed engineering, no fantasy weapons, slow side-tracking camera, realistic cinematic documentary, 16:9, no text.

### 11 — Leaving the solar system
A spacecraft passes the distant outer planets, the Sun now a bright star behind it, subtle reflected light on the craft, immense dark space, physically plausible scale, slow rear-follow camera, contemplative mood, 16:9, no text.

### 12 — Another star
Distant planetary system around a calm sun-like star, small rocky planet with a thin atmosphere visible in silhouette, scientifically plausible astronomical visualization, quiet sense of possibility, slow camera drift, 16:9, no text.

### 13 — Planetary nebula
The Sun's distant future: outer stellar layers drift outward into a delicate glowing planetary nebula, intricate gas filaments and translucent shells, white dwarf visible at the center, scientifically inspired, no supernova explosion, slow wide camera movement, 16:9, no text.

### 14 — White dwarf
A small intensely bright white dwarf centered in a vast dark field, subtle surrounding nebula fading into black, precise astronomical scale cues, quiet and restrained, slow pullback, photorealistic scientific visualization, 16:9, no text.

### 15 — Return to Earth
Present-day Earth from space, blue oceans, white clouds, thin luminous atmosphere, sunrise grazing the horizon, calm and beautiful, slow pullback revealing the planet against deep black, emotional but not sentimental, 16:9, no text.

## Negative prompt
Cartoon, anime, illustration, low-poly, plastic CGI, oversaturated colors, fantasy nebula overload, impossible lens flares, fire in vacuum, visible flames on the Sun, exploding Sun, supernova, inaccurate planet scale, duplicated planets, warped spacecraft, malformed geometry, flicker, jitter, wobble, morphing, melting details, noisy texture, compression artifacts, excessive sharpening, text, subtitles, labels, logos, watermark.

## Editing note
Use generated clips as visual coverage, not literal continuous astronomical events. Intercut wide establishing shots with detailed inserts. Add scientific labels, dates, and chapter titles in the editor so they remain sharp and editable.
