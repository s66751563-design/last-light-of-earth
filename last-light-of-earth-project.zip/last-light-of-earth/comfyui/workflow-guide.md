# Hosted ComfyUI Workflow Guide

## Goal
Generate consistent documentary visuals in ComfyUI while creating narration, music, and sound design as separate assets.

This is a model-agnostic guide, not an importable workflow JSON. Node names, model loaders, and settings vary by hosted provider and installed checkpoints.

## Recommended pipeline
1. **Text-to-image keyframes:** Create one strong still for each shot using the prompts in the shot list.
2. **Image-to-video:** Animate approved keyframes with a video model. Use low-to-moderate motion and preserve composition.
3. **Upscale and interpolate:** Only after motion is clean. Upscaling cannot repair flicker, unstable geometry, or bad source frames.
4. **Export clips:** Keep every shot as a separate file with descriptive names, such as S01-earth-night-01.mp4.
5. **Voiceover:** Generate or record narration separately from the video workflow.
6. **Edit and mix:** Assemble in a video editor; keep narration, music, and effects on separate tracks.

## A. Keyframe generation
- Load a photorealistic checkpoint suited to cinematic environments or astronomy.
- Enter the positive and negative prompts from the shot list.
- Set a 16:9 aspect ratio.
- Generate 2–4 candidates per shot at a practical resolution supported by the model.
- Review planet count, solar appearance, composition, and geometry.
- Save the chosen still and record seed, checkpoint, VAE, LoRA, and settings.

## B. Image-to-video
- Load the selected keyframe.
- Load the provider's image-to-video model and required text encoder / VAE components.
- Use the shot prompt as motion guidance; describe only the movement that should occur.
- Start with a short duration and restrained motion strength.
- Choose one slow move: drift, gentle orbit, or gradual pullback.
- Generate a low-resolution preview first, then render the approved shot at the highest reliable quality.
- If motion causes melting, flicker, or geometry changes, lower motion strength and simplify the prompt.

## C. Finishing
- Upscale only clean clips.
- Use frame interpolation only when source motion is stable; inspect for ghosting.
- Do not add fake camera shake to astronomical shots.
- Export a high-quality intermediate such as ProRes or DNxHR if supported, otherwise a high-bitrate H.264/H.265 file.
- Keep the final edit at 3840×2160, 24 fps when source quality and hardware permit.

## Starting principles
- Prefer the model's recommended resolution and frame count over forcing 4K generation.
- Generate short shots; many video models degrade on long sequences.
- Keep motion modest and singular: one camera move per shot.
- Reuse fixed seeds and reference images for continuity where supported.
- Avoid stacking many LoRAs or effects until the baseline shot is clean.
- Render a 3-shot test—Earth, Sun close-up, spacecraft—before producing the full film.

## Separate professional narration
Do not ask the video model to create speech. Create the voice track independently:
- Use a licensed human narrator or high-quality TTS service with commercial rights.
- Choose a natural conversational documentary voice, not a trailer announcer.
- Generate paragraph by paragraph to control pacing and pronunciation.
- Export clean WAV at 48 kHz, 24-bit if available.
- Leave pauses between paragraphs; do not time-compress the voice to fit rough cuts.
- Keep an unprocessed voice master.

## Suggested media folders
- assets/keyframes
- assets/clips
- assets/voice
- assets/music
- assets/sfx
- exports/previews
- exports/master

## Troubleshooting
| Problem | Likely cause | Try |
|---|---|---|
| Blurry footage | Too much motion, weak source frame, low native resolution | Improve keyframe first; reduce motion; upscale only after approval |
| Flicker | Model instability or excessive motion | Shorten clip; lower motion; simplify prompt |
| Warped planets or spacecraft | Ambiguous geometry or camera movement | Use a clean reference frame; specify one slow move |
| Poor voice | Video model speech generation | Use a separate narrator track |
| Robotic TTS | Overly dramatic settings or long generation chunks | Use shorter paragraphs and natural delivery |
| Inconsistent style | Different references, seeds, or prompt language | Reuse the visual bible and reference images |

## Provider-specific setup
The exact hosted ComfyUI service and its installed video model determine the actual nodes and settings. Do not paste generic node JSON into a different provider and expect it to work. To make this provider-specific, first identify the service, video model, available nodes, and export options.
