# THE LAST LIGHT OF EARTH
## WHEN THE SUN DIES: THE LAST JOURNEY OF HUMANITY

A cinematic, scientifically grounded space-documentary production package exploring the Sun's evolution, Earth's distant future, and the possibility that humanity's descendants may one day travel beyond our solar system.

**Scientific framing:** The Sun is expected to leave the main sequence in roughly five billion years and later become a red giant. This is a distant natural process, not an imminent threat. The film separates established stellar physics from speculative human-future scenarios.

## Project files
- [Documentary script](docs/documentary-script.md)
- [Clean narration script](docs/narration-script.md)
- [Cinematic shot list and prompts](prompts/shot-list.md)
- [Hosted ComfyUI workflow guide](comfyui/workflow-guide.md)
- [Music and sound design](production/sound-design.md)
- [Production checklist](production/checklist.md)

## Creative specification
- 16:9 widescreen; target master 3840×2160 (4K UHD), 24 fps.
- Photorealistic, scientifically grounded astronomy.
- Slow, deliberate camera movement and consistent visual references.
- Natural human documentary narrator, generated or recorded separately.
- Music and sound effects on separate tracks.
- No text, logos, subtitles, or watermarks inside generated footage.

## Production order
1. Finalize narration and pronunciation.
2. Generate and approve keyframes for each shot.
3. Animate short clips with restrained motion.
4. Create narration independently as a clean WAV track.
5. Edit picture to narration, then add licensed/original music and effects.
6. Color-match, caption, review, and export the 4K master.

**Scope:** This repository contains scripts, prompts, and workflow guidance. It does not contain rendered footage, a trained voice model, or a provider-specific importable ComfyUI workflow JSON. Exact node names and settings depend on the hosted service and installed models.

Check the usage rights of every video model, voice, music track, and sound-effect asset before publication.
