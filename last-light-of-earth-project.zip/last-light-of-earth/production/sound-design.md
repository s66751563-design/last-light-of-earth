# Sound and Music Design

## Overall approach
The film should feel immersive without sounding like a movie trailer. Space itself is silent; low rumbles, pulses, and whooshes are editorial sound design, not literal sounds travelling through vacuum.

## Narration
- Human, intimate, steady, and confident.
- Record or generate as a separate WAV file.
- Keep breaths natural; remove only distracting mouth noise.
- Use gentle EQ and compression; avoid heavy reverb.
- Narration must remain intelligible over music at all times.

## Music arc
1. **Opening:** sparse warm pad and a few restrained piano notes.
2. **Solar science:** subtle evolving synth texture and soft pulse; no aggressive percussion.
3. **Earth's future:** gradually deepen the harmony; avoid disaster-film impacts.
4. **Red giant:** broad low strings or synth swell, slow and majestic.
5. **Humanity's imagined future:** introduce a gentle hopeful motif.
6. **Interstellar passage:** spacious sustained tones and restrained rhythmic movement.
7. **Ending:** return to the opening motif, resolve softly, then allow silence.

Use original music or properly licensed tracks. Verify commercial-use and attribution requirements before publishing.

## Sound effects
- Very subtle spacecraft mechanical ambience only when the image shows a ship or habitat.
- Soft transitions and low-level cinematic impacts at chapter changes, if needed.
- No literal explosions, roaring solar flames, or loud vacuum “space wind.”
- Keep effects on their own tracks so they can be muted or balanced independently.

## Mix and delivery
- Edit at 48 kHz.
- Keep narration centered and clearly above the music.
- Avoid clipping; leave true-peak headroom and check the export on headphones and phone speakers.
- Use loudness targets appropriate to the publishing platform; verify current delivery guidance before final export.
- Export a clean narration-only stem, music stem, effects stem, and final mix.
