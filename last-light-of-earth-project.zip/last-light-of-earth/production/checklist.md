# Production Checklist

## Pre-production
- [ ] Confirm final runtime and narration wording.
- [ ] Verify science statements and uncertainty wording.
- [ ] Choose a consistent visual reference and color direction.
- [ ] Confirm video, voice, music, and sound-effect licenses.

## Visual generation
- [ ] Generate keyframes for all 15 shots.
- [ ] Approve composition before image-to-video.
- [ ] Test Earth, Sun, and spacecraft shots before full rendering.
- [ ] Keep camera movement slow and simple.
- [ ] Review every clip for flicker, warping, morphing, and artifacts.
- [ ] Save seeds and model settings for reproducibility.

## Audio
- [ ] Record or generate narration separately.
- [ ] Listen for pronunciation, pacing, and unnatural emphasis.
- [ ] Export a clean WAV master.
- [ ] Add music and effects on separate tracks.
- [ ] Confirm narration is intelligible on phone speakers.

## Edit and export
- [ ] Assemble picture to narration first.
- [ ] Add chapter titles and captions in the editor.
- [ ] Match color and exposure across clips.
- [ ] Check scientific continuity and planet scale.
- [ ] Export a review copy and watch it from beginning to end.
- [ ] Export the final 4K master only after approval.
- [ ] Save the project file, media, and audio stems.
