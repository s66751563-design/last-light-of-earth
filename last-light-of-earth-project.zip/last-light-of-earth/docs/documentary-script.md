# Documentary Script
## WHEN THE SUN DIES: THE LAST JOURNEY OF HUMANITY

**Target runtime:** 9–11 minutes  
**Tone:** awe, intimacy, scientific clarity, cautious hope.

### Logline
As the Sun slowly changes over billions of years, Earth will become uninhabitable. This film follows the science of that transformation, then imagines—clearly as speculation—how intelligence might carry its story beyond its home star.

### Chapter 1 — A familiar star (00:00–01:10)
**Picture:** Earth at night, city lights, sunrise from orbit, and a close solar-observatory view.  
**Purpose:** Make the Sun feel familiar before revealing its deep-time future.

### Chapter 2 — The clock inside the Sun (01:10–02:35)
**Picture:** Solar granulation, magnetic loops, and a clean scientific cutaway of the Sun's interior.  
**Science:** The Sun produces energy through nuclear fusion in its core. It is about 4.6 billion years old and has roughly another five billion years on the main sequence.  
**Avoid:** Explosions, flames in space, or claims that the Sun will suddenly switch off.

### Chapter 3 — A brighter star, a changing Earth (02:35–04:00)
**Picture:** Gradual solar brightening, oceans and clouds, then a restrained conceptual future Earth.  
**Science:** Solar luminosity slowly increases. Long before the red-giant phase, the warming Sun is expected to make Earth increasingly hostile to surface life. Exact timelines and outcomes carry uncertainty.

### Chapter 4 — The red giant (04:00–05:35)
**Picture:** The Sun swelling into a red giant, the inner solar system from a distant viewpoint, Earth as a small world.  
**Science:** Mercury and Venus are expected to be engulfed. Earth's ultimate fate is complex: solar mass loss and orbital evolution affect whether it is engulfed or survives as a scorched remnant. Do not state Earth's engulfment as certain.

### Chapter 5 — The last refuge (05:35–07:00)
**Picture:** A future spacecraft habitat, orbital construction, distant icy worlds, and a starship leaving the solar system.  
**Status:** Speculative future scenario, not a prediction. Ask what a spacefaring civilization might preserve: people, knowledge, art, ecosystems, and memory.

### Chapter 6 — Beyond the Sun (07:00–08:40)
**Picture:** Interstellar craft passing the outer planets, a star field, a distant planetary system.  
**Science:** Interstellar travel is far beyond present human capability. Generation ships, suspended animation, and advanced propulsion are possibilities for fiction, not established technologies.

### Chapter 7 — The last light (08:40–10:00)
**Picture:** The Sun shedding its outer layers into a planetary nebula, then a white dwarf cooling in darkness. Return to present-day Earth as a blue point.  
**Science:** The Sun is expected to end as a white dwarf. It will not become a supernova.

### Final title card
**THE LAST LIGHT OF EARTH**  
*Our story began beneath one star. Its future may not end there.*

### Editorial rules
- Keep scientific statements conservative and qualify uncertain timelines.
- Mark speculative technology with words such as “perhaps,” “might,” and “we can only imagine.”
- Do not imply the Sun is dying imminently.
- Add titles and captions in the editor, not inside generated video.
- Let important images breathe; do not cut every shot to the beat.
