# Clean Narration Script
## WHEN THE SUN DIES: THE LAST JOURNEY OF HUMANITY

**Voice direction:** Natural human documentary narrator. Warm, credible, intimate, measured. Medium-low register if suitable. Clear consonants, subtle emotion, no theatrical trailer delivery. Aim for 125–140 words per minute. Pause naturally between paragraphs.

---

Look up at the sky.

Every morning, the same star rises above our world. It warms the oceans, feeds the forests, and gives shape to almost every living thing we know.

For all of human history, the Sun has seemed permanent.

But stars are not eternal.

And one day, unimaginably far from now, the star that made our world possible will transform beyond recognition.

To understand that future, we must first understand the quiet machinery shining above us.

Deep inside the Sun, gravity presses hydrogen atoms together. Through nuclear fusion, a small amount of mass becomes energy. That energy begins a long journey outward before escaping into space as light and heat.

The Sun has been shining for about four and a half billion years. It is now in the stable phase of its life, converting hydrogen into helium in its core.

It has billions of years ahead.

But the clock is already moving.

As hydrogen is gradually used up, the Sun's structure will slowly change. Its brightness will increase over immense spans of time. The change will be almost impossible for a human lifetime to notice, yet powerful enough to reshape the future of Earth.

Long before the Sun becomes a red giant, our planet is expected to grow increasingly hostile to life as we know it.

The oceans may eventually be lost. The atmosphere will change. The blue world that once carried forests, animals, and civilizations may become a place no human could call home.

This will not happen tomorrow. It will not happen in a thousand years, or even a million.

It belongs to a future measured in billions of years.

Then, as the Sun exhausts the hydrogen in its core, it will enter a new chapter.

Its outer layers will expand. The familiar yellow-white star will become a red giant, growing vastly larger than it is today.

Mercury and Venus are expected to be swallowed. Earth's final fate is less certain. The Sun will lose mass as it evolves, changing the orbits of the planets. Whether Earth is engulfed or survives as a scorched remnant is a question shaped by complex physics.

Either way, the Earth we know will be gone.

Imagine, for a moment, that intelligence survives that far into the future.

Perhaps our descendants will no longer live on a single planet. Perhaps they will build habitats in space, travel between worlds, and learn to live beneath other suns.

Perhaps they will carry seeds, libraries, music, languages, and memories of a blue planet that existed billions of years before them.

These are possibilities, not promises. We do not know whether humanity will survive, or what forms future life might take.

Interstellar space is vast. The nearest stars are separated by distances that make today's journeys seem almost impossibly small. Reaching them would demand technologies and patience far beyond anything we possess.

A generation ship. A new kind of propulsion. A future we cannot yet imagine.

For now, these belong to the realm of speculation.

But the question remains: if one day we must leave our star, what should we take with us?

Not just machines. Not just maps.

Perhaps the most important cargo would be the knowledge of where we came from.

Eventually, the Sun will cast off its outer layers. Gas will drift into space, glowing around the remnant of the star that once warmed Earth. At its center, a white dwarf will remain: a dense stellar ember, slowly cooling over an almost unimaginable length of time.

The Sun will not explode as a supernova. Its ending will be quieter.

And somewhere in the deep future, if our story continues, a distant observer might look back toward this corner of the galaxy and wonder about the small blue world that once circled this star.

A world of oceans and storms. Of forests, cities, and voices. A world where life looked up and began to ask questions.

That world is not lost.

Not now.

Today, the Sun is shining. The oceans are moving. The night side of Earth is glowing with the lights of billions of lives.

The future is not written.

And the greatest journey may not be the one that carries us away from Earth.

It may be the one that teaches us how precious Earth has always been.

Our story began beneath one star.

Its future may not end there.

[Pause. Music resolves. Fade to black.]
